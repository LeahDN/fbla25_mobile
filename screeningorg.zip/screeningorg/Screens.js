import React, { useState, useEffect } from 'react';
import { Text, SafeAreaView, StyleSheet, View, Button, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { styles } from './Stlye'

const HomeScreen = ({ navigation }) => {
  // Declare state variables
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  // API URL
  const url = "https://raw.githubusercontent.com/LeahDN/fbla25_mobile/refs/heads/json_files/fbla_mobile/json/ancient_civilizations.json";

  // Fetch data from the API
  useEffect(() => {
    fetch(url)
      .then((resp) => resp.json())
      .then((json) => setData(json))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);

  return (
    <View style={styles.container}>
      {loading ? (
        <Text>Loading...</Text>
      ) : (
        data.map((post, index) => (
          <View key={index}>
              <View style={styles.container2}>
                <View style={styles.appButtonContainer}>
                  <Button
                    title={post.start_year}
                    onPress={() => navigation.navigate("Details", {pageName: post.name})}
                  />
                </View>
              </View>
            <Text style={styles.title}>{post.name}</Text>
            <Text>{post.info}</Text>
          </View>
        ))
      )}
      //<View style={styles.appButtonContainer2}>
       // <Button title="Profile" onPress={() => navigation.navigate("Details")} />
      //</View>
    </View>
  );
};

const DetailScreen = ({ route }) => {
  //const route = useRoute();
  const pageName = route.params?.pageName;

  <View style={styles.container}>
    <Text>{pageName}</Text>
  </View> 
};
