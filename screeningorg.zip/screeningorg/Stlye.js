import React, { useState, useEffect } from 'react';
import { Text, SafeAreaView, StyleSheet, View, Button, Alert } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  container2: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 45,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  appButtonContainer: {
    elevation: 8,
    backgroundColor: "#ded8c5",
    borderRadius: 50,
    paddingVertical: 10,
    paddingHorizontal: 10,
    width: 90,
    height: 90,
    position: 'left'
  },
  appButtonContainer2: {
    elevation: 8,
    backgroundColor: "#edc540",
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  appButtonText: {
    fontSize: 18,
    color: "#000000",
    fontWeight: "bold",
    alignSelf: "center",
    textTransform: "uppercase",
  },
});